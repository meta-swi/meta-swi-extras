
=head1 NAME

Zonk::Pronk -- blorpoesu

=head1 DESCRIPTION

This is just a test file.

This is a test Pod document in Latin-1. Its content is the last two
paragraphs of Baudelaire's I<Le Joujou du pauvre>.

A travers ces barreaux symboliques s�parant deux mondes, la grande route
et le ch�teau, l'enfant pauvre montrait � l'enfant riche son propre
joujou, que celui-ci examinait avidement comme un objet rare et inconnu.
Or, ce joujou, que le petit souillon aga�ait, agitait et secouait dans
une bo�te grill�e, c'�tait un rat vivantE<160>! Les parents, par �conomie
sans doute, avaient tir� le joujou de la vie elle-m�me. 

Et les deux enfants se riaient l'un � l'autre fraternellement, avec des
dents d'une I<�gale> blancheur.

=head2 As Verbatim

 A travers ces barreaux symboliques s�parant deux mondes, la grande route
 et le ch�teau, l'enfant pauvre montrait � l'enfant riche son propre
 joujou, que celui-ci examinait avidement comme un objet rare et inconnu.
 Or, ce joujou, que le petit souillon aga�ait, agitait et secouait dans
 une bo�te grill�e, c'�tait un rat vivant�!  Les parents, par �conomie
 sans doute, avaient tir� le joujou de la vie elle-m�me. 

 Et les deux enfants se riaient l'un � l'autre fraternellement, avec des
 dents d'une �gale blancheur.

[end]

=cut



print "HOOBOY!\n";
1;


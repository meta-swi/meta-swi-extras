#define JADE_VERSION SP_T("1.3.2")

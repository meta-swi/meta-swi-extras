// Copyright (c) 2002 Ian Castle
// See the file COPYING for copying permission.

#ifdef __GNUG__
#pragma implementation
#endif

// #include "splib.h"
// #include "MessageTable.h"

#include "stylelib.h"

#include <OpenSP/MessageModule.h>

#ifdef SP_NAMESPACE
namespace SP_NAMESPACE {
#endif

MessageModule jstyleModule;

#ifdef SP_NAMESPACE
}
#endif


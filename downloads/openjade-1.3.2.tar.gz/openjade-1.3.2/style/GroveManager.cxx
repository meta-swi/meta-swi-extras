// Copyright (c) 1997 James Clark
// See the file copying.txt for copying permission.

#include "stylelib.h"
#include "GroveManager.h"

#ifdef DSSSL_NAMESPACE
namespace DSSSL_NAMESPACE {
#endif

GroveManager::~GroveManager()
{
}

#ifdef DSSSL_NAMESPACE
}
#endif


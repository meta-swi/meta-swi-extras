
/* Generated data (by glib-mkenums) */

#ifndef __GUDEV_ENUM_TYPES_H__
#define __GUDEV_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "src/gudev/gudevenums.h" */
GType g_udev_device_type_get_type (void) G_GNUC_CONST;
#define G_TYPE_UDEV_DEVICE_TYPE (g_udev_device_type_get_type ())
G_END_DECLS

#endif /* __GUDEV_ENUM_TYPES_H__ */

/* Generated data ends here */


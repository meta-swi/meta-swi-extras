
You will need the CRYPTO package installed to build this driver,  and
potentially the ADK.

cavium_crypto sourced from:

	adk/components/source/cavium_ipsec_kame/cavium_ipsec.c

and significantly modified to suit use with OCF.  All original
copyright/ownership headers retained.

